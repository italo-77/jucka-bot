module.exports = {
  ...require('./pulls'),
  ...require('./builds'),
  ...require('./contributors'),
  ...require('./issues'),
  ...require('./commits')
};
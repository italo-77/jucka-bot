module.exports = (bot) => {
  bot.start((ctx) => {
    ctx.reply('👋 Olá! Eu sou seu bot de apoio com GitHub, IA e automações.\nDigite /painel para ver as opções.');
  });
};
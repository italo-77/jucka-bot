const chalk = require('chalk');

const hora = () => new Date().toISOString().replace('T', ' ').slice(0, 19);

const log = {
  info: (msg, ...rest) => {
    console.log(`${chalk.blue('[INFO]')} ${hora()} — ${msg}`, ...rest);
  },

  success: (msg, ...rest) => {
    console.log(`${chalk.green('[SUCESSO]')} ${hora()} — ${msg}`, ...rest);
  },

  warn: (msg, ...rest) => {
    console.warn(`${chalk.yellow('[AVISO]')} ${hora()} — ${msg}`, ...rest);
  },

  error: (msg, ...rest) => {
    console.error(`${chalk.red('[ERRO]')} ${hora()} — ${msg}`, ...rest);
  },

  debug: (msg, ...rest) => {
    if (process.env.DEBUG === 'true') {
      console.log(`${chalk.gray('[DEBUG]')} ${hora()} — ${msg}`, ...rest);
    }
  }
};

module.exports = log;